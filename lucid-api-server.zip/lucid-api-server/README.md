# Lucid API Server

API server for the Lucid Shopping Assistant app. This server proxies requests to DeepSeek AI and OpenAI APIs.

## Deployment to Google Cloud Run

1. Build the container:
   ```bash
   gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/lucid-api-server
   ```

2. Deploy to Cloud Run:
   ```bash
   gcloud run deploy lucid-api-server \
     --image gcr.io/YOUR_PROJECT_ID/lucid-api-server \
     --platform managed \
     --region europe-west2 \
     --allow-unauthenticated \
     --set-env-vars="DEEPSEEK_API_KEY=sk-2cd5da37fd2841e3987784275c8997ef,OPENAI_API_KEY=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"
   ```

## Local Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   npm start
   ```

3. For development with auto-reload:
   ```bash
   npm run dev
   ```

## API Endpoints

- `GET /` - Health check
- `POST /api/search` - Product search endpoint
- `POST /api/chat` - Chat endpoint for AI assistant 